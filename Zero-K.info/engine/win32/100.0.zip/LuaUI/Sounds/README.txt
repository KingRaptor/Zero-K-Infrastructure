
Sound files from the GNU LGPL v2.1 licensed BZFlag game

<< http://www.bzflag.org >>

  bounce.wav
  land.wav
  message_private.wav
  pop.wav
  teamgrab.wav
  flag_grab.wav
  message_admin.wav
  message_team.wav

