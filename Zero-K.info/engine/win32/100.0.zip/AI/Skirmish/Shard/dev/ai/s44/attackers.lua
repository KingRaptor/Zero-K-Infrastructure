--[[
Attackers!
]]--

attackerlist = {
	--
}
