require "spothandler"
require "unithandler"
require "attackhandler"
require "sleep"

modules = { UnitHandler, AttackHandler, MetalSpotHandler, Sleep }
